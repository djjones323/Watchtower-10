package com.watchtower.osint

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject

class MapHomeActivity : Activity() {
    private var web: WebView? = null
    private lateinit var metrics: TextView
    private lateinit var refreshButton: Button
    private lateinit var drawer: LinearLayout
    private lateinit var drawerText: TextView
    private val worker = Executors.newSingleThreadExecutor()
    private val bg = Color.rgb(3, 8, 15)
    private val blue = Color.rgb(0, 210, 255)
    private var refreshing = false
    private var aircraftPoints: List<PublicApiEngine.AircraftPoint> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        val frame = FrameLayout(this).apply { setBackgroundColor(bg) }
        val map = WebView(this).apply {
            setBackgroundColor(bg)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
        }
        web = map
        frame.addView(map, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(7), dp(12), dp(7))
            setBackgroundColor(Color.argb(232, 3, 12, 23))
        }
        val brand = TextView(this).apply {
            text = "WATCHTOWER"
            setTextColor(Color.WHITE); textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            letterSpacing = .07f
        }
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        metrics = TextView(this).apply {
            text = "LOADING…"
            setTextColor(Color.rgb(110, 255, 195)); textSize = 8f
            maxLines = 1
        }
        top.addView(smallButton("LAYERS") { showLayers() })
        top.addView(smallButton("INTEL") { startActivity(Intent(this, MainActivity::class.java)) })
        frame.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(Color.argb(245, 4, 13, 26))
            visibility = View.GONE
        }
        val drawerHead = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        drawerHead.addView(label("INTELLIGENCE BRIEF", 12, blue, true),
            LinearLayout.LayoutParams(0, -2, 1f))
        drawerHead.addView(smallButton("CLOSE") { drawer.visibility = View.GONE })
        drawer.addView(drawerHead)
        drawerText = label("Select a hotspot to inspect its evidence.", 11, Color.WHITE, false)
        val drawerScroll = android.widget.ScrollView(this).apply {
            isFillViewport = false
            addView(drawerText)
        }
        drawer.addView(drawerScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        frame.addView(drawer, FrameLayout.LayoutParams(-1, dp(174), Gravity.BOTTOM).apply {
            bottomMargin = dp(54)
        })

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(5), dp(8), dp(5))
            setBackgroundColor(Color.argb(238, 3, 12, 23))
        }
        refreshButton = smallButton("↻ REFRESH") { refreshMap() }
        bottom.addView(refreshButton, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(smallButton("INTEL BRIEF") {
            drawer.visibility = if (drawer.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            updateDrawer()
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(smallButton("PROVIDERS") {
            startActivity(Intent(this, ProviderAccessActivity::class.java))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(smallButton("PIZZA") { fetchPizzaDirectory() },
            LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(smallButton("WORLD") {
            web?.evaluateJavascript("fitWorld();", null)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        frame.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(frame)

        renderMap()
        // Refresh public feeds after cached signals have appeared; failures leave cached data visible.
        refreshMap()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(value: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            text = value; textSize = size.toFloat(); setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(5), 0, dp(5))
        }

    private fun smallButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 9f; setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(20, 65, 88))
        setPadding(dp(5), dp(2), dp(5), dp(2))
        minHeight = dp(38)
        setOnClickListener { action() }
    }

    private fun showLayers() {
        val categories = Categories.all + listOf("Aircraft positions (ADS-B)", "Maritime public alerts")
        val checked = BooleanArray(categories.size) { true }
        AlertDialog.Builder(this).setTitle("MAP DATA LAYERS")
            .setMultiChoiceItems(categories.toTypedArray(), checked) { _, which, enabled ->
                web?.evaluateJavascript("setCategoryVisible(${JSONObject.quote(categories[which])},$enabled);", null)
            }.setPositiveButton("Done", null).show()
    }

    private fun refreshMap() {
        if (refreshing) return
        refreshing = true
        refreshButton.text = "FETCHING…"
        metrics.text = "UPDATING FEEDS…"
        worker.execute {
            var note = ""
            try {
                val old = SignalStore.load(this)
                val rss = FeedEngine.fetchAll()
                val apis = PublicApiEngine.fetch(this)
                try { aircraftPoints = PublicApiEngine.fetchAircraftPoints() } catch (_: Exception) { aircraftPoints = emptyList() }
                val merged = (old + rss.signals + apis.signals)
                    .distinctBy { it.id }.sortedByDescending { it.date }.take(600)
                SignalStore.save(this, merged)
                note = "RSS ${rss.successful} · API ${apis.ok} · ${rss.failed + apis.failed} failed"
            } catch (e: Exception) {
                note = "Refresh incomplete · cached records retained"
            }
            runOnUiThread {
                refreshing = false
                refreshButton.text = "↻ REFRESH"
                metrics.text = note
                renderMap()
                updateDrawer()
            }
        }
    }

    private fun fetchPizzaDirectory() {
        refreshButton.text = "PIZZA…"
        worker.execute {
            val result = try { FreePizzaEngine.fetch(this) } catch (e: Exception) { null }
            runOnUiThread {
                refreshButton.text = "↻ REFRESH"
                val msg = if (result != null) {
                    "PENTAGON-AREA PIZZA DIRECTORY\\n${result.venuesFound} named venues found in OpenStreetMap.\\nFetched: ${java.text.SimpleDateFormat("MMM d, HH:mm", java.util.Locale.US).format(java.util.Date(result.fetchedAt))}\\n\\nThis is venue-directory data, NOT restaurant foot traffic or Google Popular Times. No 1–10 traffic score is fabricated."
                } else "Free venue lookup unavailable right now. No traffic score has been inferred."
                AlertDialog.Builder(this).setTitle("PENTAGON PIZZA INDICATOR · EXPERIMENTAL")
                    .setMessage(msg).setPositiveButton("OK", null).show()
            }
        }
    }

    private fun updateDrawer() {
        val signals = SignalStore.load(this).sortedByDescending { it.date }
        val hotspots = AnomalyEngine.analyze(signals)
        val recent = signals.take(5).joinToString("\\n") { "• ${it.category}: ${it.title.take(95)}" }
        drawerText.text = "72-HOUR SNAPSHOT\\n${signals.size} saved records · ${hotspots.size} regional hotspots · ${hotspots.count { it.score >= 8 }} high-interest areas\\n\\nLATEST PUBLIC RECORDS\\n${recent.ifBlank { "No records loaded yet. Refresh to check public feeds." }}\\n\\nScores indicate unusual public-source activity, not threat probability."
    }

    private fun renderMap() {
        val signals = SignalStore.load(this)
        val hotspots = AnomalyEngine.analyze(signals)
        val data = JSONArray()
        hotspots.forEach { h ->
            data.put(JSONObject().put("region", h.region).put("lat", h.latitude)
                .put("lon", h.longitude).put("score", h.score).put("count", h.signalCount)
                .put("categories", h.categories.joinToString(" · "))
                .put("publishers", h.publishers).put("explanation", h.explanation))
        }
        val signalData = JSONArray()
        signals.forEach { item ->
            signalData.put(JSONObject().put("region", item.region).put("category", item.category)
                .put("title", item.title).put("publisher", item.publisher).put("url", item.url)
                .put("date", item.date).put("official", item.official))
        }
        val aircraftData = JSONArray()
        aircraftPoints.forEach { a ->
            aircraftData.put(JSONObject().put("lat",a.lat).put("lon",a.lon).put("callsign",a.callsign)
                .put("altitude",a.altitudeFt).put("speed",a.speedKt))
        }
        val html = """
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
*{box-sizing:border-box}html,body,#map{height:100%;width:100%;margin:0;background:#03080f;font-family:Arial,sans-serif;overflow:hidden}
.leaflet-tile-pane{filter:invert(1) hue-rotate(180deg) brightness(.78) contrast(1.08)}
.leaflet-control-attribution{background:rgba(2,8,16,.72)!important;color:#8297aa!important;font-size:8px!important}
.leaflet-control-attribution a{color:#7ddcff!important}
.hud{position:absolute;z-index:700;background:rgba(4,13,26,.91);border:1px solid rgba(0,211,255,.5);color:#e8f7ff;box-shadow:0 0 18px rgba(0,190,255,.08)}
.metrics{left:10px;top:66px;padding:8px 10px;font-size:10px;line-height:1.65;max-width:166px}
.metrics b{color:#00d9ff;letter-spacing:1px}
.legend{right:10px;top:66px;padding:7px;font-size:9px;line-height:1.8}
.dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:5px}
.detail{left:10px;right:10px;bottom:62px;padding:9px 11px;font-size:10px;line-height:1.35;max-height:18%;overflow:auto}
.detail strong{color:#00d9ff;letter-spacing:1px}
.timeline{position:absolute;z-index:710;left:10px;right:10px;bottom:205px;padding:7px;background:rgba(4,13,26,.94);border:1px solid rgba(0,211,255,.5);display:flex;gap:5px;justify-content:space-between}
.timeline button{background:#143f56;color:#dff8ff;border:1px solid #16718c;border-radius:3px;padding:7px 8px;font-size:9px}
.timeline button.active{background:#00a9cf;color:#001018}
.leaflet-popup-content-wrapper,.leaflet-popup-tip{background:#081727;color:#e8f7ff;border:1px solid #087b9c}
.leaflet-popup-content{font-size:11px;line-height:1.45}
@keyframes pulse{0%{stroke-opacity:.8;fill-opacity:.22}50%{stroke-opacity:.25;fill-opacity:.07}100%{stroke-opacity:.8;fill-opacity:.22}}
.pulse{animation:pulse 2.6s ease-in-out infinite}
</style></head><body>
<div id="map"></div>
<div class="hud metrics"><b>GLOBAL ANOMALY FIELD</b><br>RECORDS: ${signals.size}<br>HOTSPOTS: ${hotspots.size}<br>HIGH INTEREST: ${hotspots.count { it.score >= 8 }}<br>WINDOW: 72 HOURS</div>
<div class="hud legend"><span class="dot" style="background:#ff3d55"></span>HIGH<br><span class="dot" style="background:#ff9b39"></span>ELEVATED<br><span class="dot" style="background:#a65cff"></span>WATCH</div>
<div class="timeline" id="timeline"><button class="active" onclick="setWindow(72,this)">72H</button><button onclick="setWindow(24,this)">24H</button><button onclick="setWindow(168,this)">7D</button><button onclick="setWindow(720,this)">30D</button></div>
<div class="hud detail"><strong id="sel">GLOBAL VIEW · SELECT A HOTSPOT</strong><div id="desc">Public-source activity clusters. Select a hotspot for its evidence. Scores are not threat probabilities.</div></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const items=__DATA__;
const records=__SIGNALS__;
const aircraft=__AIRCRAFT__;
const map=L.map('map',{worldCopyJump:true,zoomControl:true,minZoom:1,maxZoom:9}).setView([18,0],1);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);
let layers=[];
function fitWorld(){map.fitBounds([[-58,-180],[82,180]],{padding:[12,12]});}
function col(v){return v>=8?'#ff3d55':v>=5?'#ff9b39':'#a65cff'}
function regionPoint(r){let q=r.toLowerCase();if(q.includes('united states')||q.includes('washington')||q.includes('pentagon'))return [39,-98];if(q.includes('europe')||q.includes('france')||q.includes('germany')||q.includes('uk'))return [50,12];if(q.includes('africa'))return [2,20];if(q.includes('middle east')||q.includes('israel')||q.includes('iran'))return [29,43];if(q.includes('china'))return [35,103];if(q.includes('japan'))return [36,138];if(q.includes('ukraine'))return [49,32];return [12,0];}
function setCategoryVisible(cat,on){layers.forEach(x=>{if(x.cats.includes(cat)){if(on){x.halo.addTo(map);x.pin.addTo(map)}else{map.removeLayer(x.halo);map.removeLayer(x.pin)}}});if(cat==='Aircraft positions (ADS-B)')airLayer.eachLayer(l=>on?l.addTo(map):map.removeLayer(l));if(cat==='Maritime public alerts')seaLayer.eachLayer(l=>on?l.addTo(map):map.removeLayer(l));}
function select(h){document.getElementById('sel').textContent=h.region.toUpperCase()+' · INDEX '+h.score+'/10';document.getElementById('desc').textContent=h.count+' records · '+h.categories+' · '+h.publishers+' publishers. '+h.explanation+' Activity indicator only; not a threat assessment.'}
let windowHours=72;
function setWindow(hours,btn){windowHours=hours;document.querySelectorAll('#timeline button').forEach(b=>b.classList.remove('active'));btn.classList.add('active');drawRecords();}
function drawRecords(){layers.forEach(x=>map.removeLayer(x.halo));layers.forEach(x=>map.removeLayer(x.pin));layers=[];const cutoff=Date.now()-windowHours*3600000;const grouped={};records.filter(r=>r.date>=cutoff).forEach(r=>{let k=r.region||'International';(grouped[k]??=[]).push(r)});Object.keys(grouped).forEach(region=>{let a=grouped[region],cats=[...new Set(a.map(x=>x.category))],pubs=[...new Set(a.map(x=>x.publisher))].length;if(a.length<2)return;let score=Math.min(10,Math.max(1,Math.round(Math.min(10,a.length*2)*.25+Math.min(10,cats.length*2)*.25+Math.min(10,pubs*2)*.2+(a.filter(x=>x.official).length*10/a.length)*.15+5*.15)));let pt=regionPoint(region),h={region,lat:pt[0],lon:pt[1],score,count:a.length,categories:cats.join(' · '),publishers:pubs,explanation:a.length+' public records in selected time window.'};let c=col(score);let halo=L.circle(pt,{radius:260000+score*100000,color:c,weight:1,opacity:.65,fillColor:c,fillOpacity:.22,className:'pulse'}).addTo(map);let pin=L.circleMarker(pt,{radius:5+score,color:'#fff',weight:1,fillColor:c,fillOpacity:1}).addTo(map);pin.bindPopup('<b>'+region+'</b><br>Index '+score+'/10<br>'+a.length+' records<br>'+cats.join(', '));pin.on('click',()=>select(h));layers.push({cats,halo,pin});});}
const airLayer=L.layerGroup();aircraft.forEach(a=>{let marker=L.circleMarker([a.lat,a.lon],{radius:4,color:'#e5faff',weight:1,fillColor:'#00d9ff',fillOpacity:.95});marker.bindPopup('ADS-B position<br>'+a.callsign+'<br>Altitude: '+(a.altitude||'not reported')+' ft<br>Speed: '+(a.speed||'not reported')+' kt<br>Community receiver coverage; not a complete aircraft picture.');airLayer.addLayer(marker);}); 
const seaLayer=L.layerGroup();records.filter(r=>r.category.toLowerCase().includes('maritime')).forEach(r=>{let pt=regionPoint(r.region);let marker=L.circleMarker(pt,{radius:5,color:'#fff',fillColor:'#21c8c0',fillOpacity:.9});marker.bindPopup('Maritime public-source report<br>'+r.title+'<br>'+r.publisher);seaLayer.addLayer(marker);});
fitWorld();drawRecords();airLayer.addTo(map);seaLayer.addTo(map);
</script></body></html>
        """.trimIndent().replace("__DATA__", data.toString())
            .replace("__SIGNALS__", signalData.toString()).replace("__AIRCRAFT__", aircraftData.toString())
        web?.loadDataWithBaseURL("https://unpkg.com/", html, "text/html", "UTF-8", null)
    }

    override fun onDestroy() {
        web?.destroy()
        web = null
        worker.shutdown()
        super.onDestroy()
    }
}
