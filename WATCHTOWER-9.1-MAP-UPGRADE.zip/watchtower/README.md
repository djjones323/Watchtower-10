# WATCHTOWER Android

Native Android research dashboard for tracking public, open-source resilience and infrastructure signals.

## Current prototype features

- Nine research categories: restaurant activity, embassy activity, flight activity, maritime activity, energy infrastructure, communications, government procurement, civil defence, and financial signals.
- RSS/Atom feed refresh from a set of public sources.
- Primary-source and discovery-feed distinction.
- Local historical signal storage (up to 600 records).
- Transparent 1–10 evidence-priority score.
- Separate 1–10 source-stated imminence indicator, based on an explicit time horizon in the source (not a probability estimate).
- Manual signal entry with source reliability, corroboration, and stated timing fields.
- Periodic background refresh using Android JobScheduler (six-hour cadence; Android controls exact execution time).
- Notifications for new official-feed items that meet the high-priority scoring threshold.
- JSON export of saved history.

## Important scoring interpretation

The evidence-priority score is a research-priority score, not a probability that a war, attack, or other event is imminent. It is calculated from:

- Source reliability: 30%
- Independent corroboration: 25%
- Unusualness: 20%
- Time sensitivity: 15%
- Potential public impact: 10%

A separate source-stated imminence indicator maps explicit timing labels to a display score: immediate official warning=10, within 7 days=8, within 30 days=6, ongoing=4, historical or not stated=1. It does not predict whether an event will occur. The feed engine gives official government feeds a higher initial source-reliability value than news-discovery feeds. Keyword-based urgency and timing extraction are heuristics and must be checked against the original source. Corroboration is not automatically inferred from similar headlines; the user can enter an independent-source count when adding a record. Similar headlines and syndicated reporting must not be treated as independent confirmation.

## Feed sources in this prototype

Official feeds:

- CISA Cybersecurity Advisories: https://www.cisa.gov/cybersecurity-advisories/all.xml
- CISA News: https://www.cisa.gov/news-events/news.xml
- Federal Reserve press releases: https://www.federalreserve.gov/feeds/press_all.xml
- FEMA news releases: https://www.fema.gov/news-releases.xml
- NATO news: https://www.nato.int/cps/en/natohq/news_rss.xml
- Federal Register emergency-preparedness search: https://www.federalregister.gov/documents/search.atom?conditions%5Bterm%5D=emergency%20preparedness

Discovery-only Google News RSS queries are included for the nine categories. Those feeds are secondary discovery aids, not primary evidence. The app records feed success/failure counts; endpoints may change, rate-limit requests, or become unavailable. The app does not claim all nine categories have authoritative live feeds. Restaurant activity is especially weak and is treated as a contextual indicator only.

## Privacy and data handling

- Saved signal records are stored locally in Android SharedPreferences.
- No user account or backend is included.
- Feed requests go directly to the listed public endpoints.
- No precise location, contacts, microphone, camera, or device identifiers are collected by this app.
- Notifications require Android notification permission.

## Build the APK

This workspace does not contain the Android SDK, Android build-tools, or Gradle executable, so an installable APK could not be compiled or tested here.

To build on a computer with Android Studio installed:

1. Open this `watchtower` folder in Android Studio.
2. Allow Android Studio to install the Android SDK Platform 35 and matching build tools if prompted.
3. Sync the Gradle project.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will create the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.

For a release APK, configure a signing key in Android Studio and use **Build > Generate Signed Bundle / APK**.

## Known limitations

- No live AIS, ADS-B, Pentagon-area restaurant traffic, market-price, or paid procurement API integration is included. Such sources require vetted data access and historical baselines; this prototype uses public RSS/Atom feeds and manual entries.
- No automated claim is made that multiple sources are independent. Corroboration is user-entered in this version.
- Android JobScheduler refreshes approximately every six hours when network and battery conditions allow; it is not an exact alarm or real-time surveillance system.
- Background refresh is scheduled when the app is opened. The job is not persisted across reboot in this prototype.
- Feed timestamps fall back to fetch time if a publisher omits or uses an unsupported date format.
- The app is an OSINT research aid, not an emergency-warning authority. Follow official emergency instructions.


## Build from an Android phone (no computer)

You can use GitHub Actions as a free cloud build machine. This project includes `.github/workflows/build-apk.yml` for that purpose.

1. Create a GitHub account at https://github.com/ if you do not already have one.
2. Create a new repository. A private repository is fine.
3. Upload `WATCHTOWER-Android-Project.zip` to the repository root.
4. In the repository, choose **Add file > Create new file** and name it `.github/workflows/build-apk.yml`. Paste the workflow contents from this project's `.github/workflows/build-apk.yml` file and commit it. (If you uploaded the extracted project files instead of the ZIP, the included workflow can build directly only after adjusting the workflow; the supplied workflow expects the ZIP in the repository root.)
5. Open the repository's **Actions** tab, select **Build WATCHTOWER APK**, choose **Run workflow**, and run it on the default branch.
6. When the run completes successfully, open the run and download the **WATCHTOWER-debug-APK** artifact. It downloads as a ZIP; extract it on your phone to get `app-debug.apk`.
7. Tap `app-debug.apk` to install. Android may ask you to allow installation from the app you used to open the file.

The first cloud build may take several minutes. GitHub's free Actions allowance is sufficient for occasional builds. Keep the repository private if you prefer not to publish the source project. The APK is a debug build, not a Play Store release.


## WATCHTOWER 2.0 upgrade
- Android target SDK 34 to avoid forced edge-to-edge overlap on Android 15 devices.
- HTML entity decoding in source descriptions.
- Refresh history snapshots (last 24 refreshes) stored locally.
- Feed failure names are displayed after refresh.
- Experimental Pizza Pulse counts restaurant-activity news mentions over 24 hours; it is explicitly not a measure of actual restaurant traffic.
- Possible cross-source headline matches are surfaced as leads only, not automated corroboration.


## WATCHTOWER 3.0 additions
- Editable local keyword watchlist with a dedicated Watchlist matches filter. Matches are prompts for review, not threat determinations.
- Candidate event clusters based on headline token similarity and distinct publisher names. These are not verified independent corroboration.
- 24-hour category activity volume and refresh trend summaries.
- Experimental Pentagon/restaurant-related media mention pulse; it does not measure restaurant visits, orders, or operational activity.
- Cleaner HTML summary rendering and improved placement of the intelligence desk panel.
- App version 3.0.0 (versionCode 3).

The app remains a public RSS/Atom monitor. It does not provide live aircraft transponder, vessel AIS, private procurement, market tick, geolocation, or restaurant foot-traffic data. Keyword hits and volume changes can be noisy; always open and evaluate primary sources.


## WATCHTOWER 4.0 — Anomaly Globe prototype

The main dashboard now leads with an interactive globe-style activity field. Tap a plotted hotspot to inspect its region, anomaly index, record count, contributing categories, distinct publishers, and scoring explanation. The current hotspot engine uses a rolling 72-hour window and combines recent record volume, domain diversity, publisher diversity, official-feed share, and high-priority record share. It is an explainable activity index, not a threat probability.

Important limitations: geographic placement currently uses broad region-name matching and approximate region coordinates; it is not precision geolocation. A hotspot is only plotted when at least two recent records share a normalized region. The globe is a native stylized projection, not a live satellite basemap. The nine monitoring categories remain represented in the feed layer, but this build does **not** yet contain dedicated live integrations for every specialist provider (for example ADS-B aircraft positions, EIA time series, or a global AIS stream). Those require separate provider adapters, terms/rate-limit handling, and in some cases free API registration. Do not interpret missing hotspots as an all-clear.

The current data pipeline still refreshes public RSS/Atom feeds on demand and through Android's periodic job scheduler. Android may defer background jobs; this is not an always-on server.


## WATCHTOWER 5.0 additions
- Dedicated Provider Access screen for EIA, OpenSky, and AISStream credentials.
- Provider values are encrypted locally with an AES-GCM key held by Android Keystore.
- DC Pizza Indicator displays related public-media discovery mentions over 24 hours.
- Pizza Indicator is explicitly not a measure of orders, delivery volume, or restaurant foot traffic.

Important: the Provider Access screen is a secure local credential vault and registration launcher. It does not yet implement provider authentication or live API adapters. Credentials are not transmitted to a server. Never enter unrelated personal account passwords.


## WATCHTOWER 6.0 data integrations
Connected on refresh:
- adsb.lol public military aircraft snapshot endpoint (free public data; receiver coverage is incomplete).
- National Weather Service active alerts API (free public official data).
- USAspending V2 recent Department of Defense award search (public API; award records are context, not threat evidence).
- EIA hourly PJM regional electricity reading when an EIA API key is entered.

Optional live restaurant traffic:
- BestTime live venue endpoint for a configured sample of pizza businesses near the Pentagon/Crystal City corridor.
- Requires a BestTime private API key and a paid plan; each live venue request consumes API credits. The app only includes venues with an actual live reading; unavailable venues are excluded, not treated as zero.
- Score = rounded average live busyness / 10, clamped to 1–10. The provider's live busyness is relative to each venue's own weekly peak, not an absolute count of visitors.
- This is a public-venue activity curiosity and has no validated predictive relationship to government activity.

Not yet integrated as live adapters:
- OpenSky account/OAuth flow.
- AISStream server-side WebSocket proxy (AISStream explicitly recommends keeping API keys server-side).
- EIA data beyond the single PJM hourly series.
- Communications, embassy and financial categories continue to receive RSS/discovery sources; these are not all direct API adapters.

Provider keys are encrypted at rest using Android Keystore. Direct use of a private BestTime key from a personal Android app still carries account-abuse risk if the device/app is compromised. A server-side proxy is the safer production architecture.


## WATCHTOWER 7.0 — free DC pizza indicator
- Removed BestTime paid API key field and paid live-traffic adapter.
- Added OpenStreetMap Overpass lookup for pizza/Italian venues around the Pentagon/Crystal City area. This is real public venue-directory data, not footfall.
- Added a manual Google Maps Popular Times observation log. User opens Google Maps, observes the displayed busyness, and records a 1–10 reading with a venue/time note.
- The displayed 1–10 score is explicitly a manually observed reading; no automatic live footfall score is fabricated.
- OpenStreetMap data is provided under ODbL; attribution must be retained. Overpass is a shared public service subject to fair-use limits. Do not poll frequently.
- Google Popular Times is based on aggregated and anonymized location data and appears only for places with sufficient visit data. Google does not expose these measurements as an ordinary official Places API field.


## WATCHTOWER 8.0 — global operations map redesign
- Replaced the hand-drawn oval globe with a WebView-based interactive world map using Leaflet and CARTO dark basemap tiles.
- Map supports pan, zoom, regional hotspot markers, intensity halos, selectable hotspot list, evidence summaries and source/category details.
- Dark HUD overlays, regional hotspot panel, severity legend, bottom detail strip and atmospheric horizon accent follow the user's supplied visual reference.
- Basemap requires internet connectivity. CARTO/OSM tile service availability and fair-use policies apply; attribution is shown on map.
- Hotspot placement still depends on region geocoding in the current anomaly engine; approximate regional coordinates are not precision geolocation.
- Heat halos visualize the engine's relative activity score and are not a threat probability.


## WATCHTOWER 8.1 UI corrections
- Corrected free DC Pizza panel: removed obsolete BestTime wording and paid traffic button; provides OSM free venue lookup, manual Google Maps Popular Times observations, and direct Google Maps search.
- Moved the intelligence/field-notes panel below the map so the global map appears directly under the title.
- Replaced CARTO tile endpoint with standard OpenStreetMap tiles and a CSS dark treatment; attribution remains visible. This avoids the API-key-required tile watermark. OSM tiles are a shared community service; use modest requests and respect tile usage policy.
- Version 8.1.0.


## WATCHTOWER 9.0 — map-first full-screen home
- Launcher now opens directly into an edge-to-edge, full-screen interactive Leaflet world map.
- Map fills the screen with compact HUD metrics, hotspot intensity halos, legend, selectable evidence details, zoom/pan, layer menu, refresh, provider access and reset-view controls.
- Existing detailed dashboard remains available from the INTEL button.
- Map uses public OpenStreetMap tiles with attribution; internet required. Respect shared tile usage policies.
- Hotspot positions remain region-level approximations where source records lack precise coordinates.


## WATCHTOWER 9.1 — map-first usability upgrade
- Opens at a world-wide extent with fit-to-world bounds.
- Displays cached records immediately, then automatically refreshes RSS and public API sources on launch.
- Refresh progress/status is shown in the top toolbar; failed refreshes retain cached records.
- Corrected Android system-bar handling and compact toolbar layout to avoid clipped title/controls.
- Added expandable native Intelligence Brief drawer with latest records and aggregate counts.
- Added multi-select category layer visibility controls, reset-to-world, refresh and provider access.
- OpenStreetMap attribution remains visible; map requires internet for basemap tiles.
