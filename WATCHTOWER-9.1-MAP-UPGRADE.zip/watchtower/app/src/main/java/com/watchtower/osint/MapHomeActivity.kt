package com.watchtower.osint

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject

class MapHomeActivity : Activity() {
    private var web: WebView? = null
    private lateinit var metrics: TextView
    private lateinit var refreshButton: Button
    private lateinit var drawer: LinearLayout
    private lateinit var drawerText: TextView
    private val worker = Executors.newSingleThreadExecutor()
    private val bg = Color.rgb(3, 8, 15)
    private val blue = Color.rgb(0, 210, 255)
    private var refreshing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        val frame = FrameLayout(this).apply { setBackgroundColor(bg) }
        val map = WebView(this).apply {
            setBackgroundColor(bg)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
        }
        web = map
        frame.addView(map, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(7), dp(12), dp(7))
            setBackgroundColor(Color.argb(232, 3, 12, 23))
        }
        val brand = TextView(this).apply {
            text = "WATCHTOWER\\nGLOBAL ANOMALY FIELD"
            setTextColor(Color.WHITE); textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            letterSpacing = .07f
        }
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        metrics = TextView(this).apply {
            text = "LOADING PUBLIC DATA…"
            setTextColor(Color.rgb(110, 255, 195)); textSize = 9f
        }
        top.addView(metrics)
        top.addView(smallButton("LAYERS") { showLayers() })
        top.addView(smallButton("INTEL") { startActivity(Intent(this, MainActivity::class.java)) })
        frame.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(Color.argb(245, 4, 13, 26))
            visibility = View.GONE
        }
        val drawerHead = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        drawerHead.addView(label("INTELLIGENCE BRIEF", 12, blue, true),
            LinearLayout.LayoutParams(0, -2, 1f))
        drawerHead.addView(smallButton("CLOSE") { drawer.visibility = View.GONE })
        drawer.addView(drawerHead)
        drawerText = label("Select a hotspot to inspect its evidence.", 11, Color.WHITE, false)
        drawer.addView(drawerText)
        frame.addView(drawer, FrameLayout.LayoutParams(-1, dp(190), Gravity.BOTTOM))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(5), dp(8), dp(5))
            setBackgroundColor(Color.argb(238, 3, 12, 23))
        }
        refreshButton = smallButton("↻ REFRESH") { refreshMap() }
        bottom.addView(refreshButton, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(smallButton("INTEL BRIEF") {
            drawer.visibility = if (drawer.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            updateDrawer()
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(smallButton("PROVIDERS") {
            startActivity(Intent(this, ProviderAccessActivity::class.java))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(smallButton("WORLD") {
            web?.evaluateJavascript("fitWorld();", null)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        frame.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(frame)

        renderMap()
        // Refresh public feeds after cached signals have appeared; failures leave cached data visible.
        refreshMap()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(value: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            text = value; textSize = size.toFloat(); setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(5), 0, dp(5))
        }

    private fun smallButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 9f; setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(20, 65, 88))
        setPadding(dp(5), dp(2), dp(5), dp(2))
        minHeight = dp(38)
        setOnClickListener { action() }
    }

    private fun showLayers() {
        val categories = Categories.all
        val checked = BooleanArray(categories.size) { true }
        AlertDialog.Builder(this).setTitle("MAP DATA LAYERS")
            .setMultiChoiceItems(categories.toTypedArray(), checked) { _, which, enabled ->
                web?.evaluateJavascript("setCategoryVisible(${JSONObject.quote(categories[which])},$enabled);", null)
            }.setPositiveButton("Done", null).show()
    }

    private fun refreshMap() {
        if (refreshing) return
        refreshing = true
        refreshButton.text = "FETCHING…"
        metrics.text = "UPDATING PUBLIC FEEDS"
        worker.execute {
            var note = ""
            try {
                val old = SignalStore.load(this)
                val rss = FeedEngine.fetchAll()
                val apis = PublicApiEngine.fetch(this)
                val merged = (old + rss.signals + apis.signals)
                    .distinctBy { it.id }.sortedByDescending { it.date }.take(600)
                SignalStore.save(this, merged)
                note = "RSS ${rss.successful} OK · API ${apis.ok} OK · ${rss.failed + apis.failed} failed"
            } catch (e: Exception) {
                note = "Refresh incomplete · cached records retained"
            }
            runOnUiThread {
                refreshing = false
                refreshButton.text = "↻ REFRESH"
                metrics.text = note
                renderMap()
                updateDrawer()
            }
        }
    }

    private fun updateDrawer() {
        val signals = SignalStore.load(this).sortedByDescending { it.date }
        val hotspots = AnomalyEngine.analyze(signals)
        val recent = signals.take(5).joinToString("\\n") { "• ${it.category}: ${it.title.take(95)}" }
        drawerText.text = "72-HOUR SNAPSHOT\\n${signals.size} saved records · ${hotspots.size} regional hotspots · ${hotspots.count { it.score >= 8 }} high-interest areas\\n\\nLATEST PUBLIC RECORDS\\n${recent.ifBlank { "No records loaded yet. Refresh to check public feeds." }}\\n\\nScores indicate unusual public-source activity, not threat probability."
    }

    private fun renderMap() {
        val signals = SignalStore.load(this)
        val hotspots = AnomalyEngine.analyze(signals)
        val data = JSONArray()
        hotspots.forEach { h ->
            data.put(JSONObject().put("region", h.region).put("lat", h.latitude)
                .put("lon", h.longitude).put("score", h.score).put("count", h.signalCount)
                .put("categories", h.categories.joinToString(" · "))
                .put("publishers", h.publishers).put("explanation", h.explanation))
        }
        val html = """
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
*{box-sizing:border-box}html,body,#map{height:100%;width:100%;margin:0;background:#03080f;font-family:Arial,sans-serif;overflow:hidden}
.leaflet-tile-pane{filter:invert(1) hue-rotate(180deg) brightness(.78) contrast(1.08)}
.leaflet-control-attribution{background:rgba(2,8,16,.72)!important;color:#8297aa!important;font-size:8px!important}
.leaflet-control-attribution a{color:#7ddcff!important}
.hud{position:absolute;z-index:700;background:rgba(4,13,26,.91);border:1px solid rgba(0,211,255,.5);color:#e8f7ff;box-shadow:0 0 18px rgba(0,190,255,.08)}
.metrics{left:10px;top:66px;padding:8px 10px;font-size:10px;line-height:1.65;max-width:166px}
.metrics b{color:#00d9ff;letter-spacing:1px}
.legend{right:10px;top:66px;padding:7px;font-size:9px;line-height:1.8}
.dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:5px}
.detail{left:10px;right:10px;bottom:62px;padding:9px 11px;font-size:10px;line-height:1.35;max-height:18%;overflow:auto}
.detail strong{color:#00d9ff;letter-spacing:1px}
.leaflet-popup-content-wrapper,.leaflet-popup-tip{background:#081727;color:#e8f7ff;border:1px solid #087b9c}
.leaflet-popup-content{font-size:11px;line-height:1.45}
</style></head><body>
<div id="map"></div>
<div class="hud metrics"><b>GLOBAL ANOMALY FIELD</b><br>RECORDS: ${signals.size}<br>HOTSPOTS: ${hotspots.size}<br>HIGH INTEREST: ${hotspots.count { it.score >= 8 }}<br>WINDOW: 72 HOURS</div>
<div class="hud legend"><span class="dot" style="background:#ff3d55"></span>HIGH<br><span class="dot" style="background:#ff9b39"></span>ELEVATED<br><span class="dot" style="background:#a65cff"></span>WATCH</div>
<div class="hud detail"><strong id="sel">GLOBAL VIEW · SELECT A HOTSPOT</strong><div id="desc">Public-source activity clusters. Select a hotspot for its evidence. Scores are not threat probabilities.</div></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const items=__DATA__;
const map=L.map('map',{worldCopyJump:true,zoomControl:true,minZoom:1,maxZoom:9}).setView([18,0],1);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);
let layers=[];
function fitWorld(){map.fitBounds([[-58,-180],[82,180]],{padding:[12,12]});}
function col(v){return v>=8?'#ff3d55':v>=5?'#ff9b39':'#a65cff'}
function setCategoryVisible(cat,on){layers.forEach(x=>{if(x.cats.includes(cat)){if(on){x.halo.addTo(map);x.pin.addTo(map)}else{map.removeLayer(x.halo);map.removeLayer(x.pin)}}})}
function select(h){document.getElementById('sel').textContent=h.region.toUpperCase()+' · INDEX '+h.score+'/10';document.getElementById('desc').textContent=h.count+' records · '+h.categories+' · '+h.publishers+' publishers. '+h.explanation+' Activity indicator only; not a threat assessment.'}
items.forEach(h=>{
 const c=col(h.score);
 const halo=L.circle([h.lat,h.lon],{radius:260000+h.score*100000,color:c,weight:1,opacity:.65,fillColor:c,fillOpacity:.22}).addTo(map);
 const pin=L.circleMarker([h.lat,h.lon],{radius:5+h.score,color:'#fff',weight:1,fillColor:c,fillOpacity:1}).addTo(map);
 pin.bindPopup('<b>'+h.region+'</b><br>Index '+h.score+'/10<br>'+h.count+' records<br>'+h.categories);
 pin.on('click',()=>select(h));
 layers.push({cats:h.categories.split(' · '),halo:halo,pin:pin});
});
fitWorld();
if(items.length)select(items[0]);
</script></body></html>
        """.trimIndent().replace("__DATA__", data.toString())
        web?.loadDataWithBaseURL("https://unpkg.com/", html, "text/html", "UTF-8", null)
    }

    override fun onDestroy() {
        web?.destroy()
        web = null
        worker.shutdown()
        super.onDestroy()
    }
}
