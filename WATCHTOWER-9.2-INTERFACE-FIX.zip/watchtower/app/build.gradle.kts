plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.watchtower.osint"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.watchtower.osint"
        minSdk = 26
        targetSdk = 34
        versionCode = 12
        versionName = "9.2.0"
    }
}
