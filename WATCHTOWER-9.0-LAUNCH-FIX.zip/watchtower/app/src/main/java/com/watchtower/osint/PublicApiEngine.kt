package com.watchtower.osint

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object PublicApiEngine {
    data class Result(val signals: List<Signal>, val ok: Int, val failed: Int, val notes: List<String>)

    fun fetch(context: Context): Result {
        val out = mutableListOf<Signal>()
        val notes = mutableListOf<String>()
        var ok = 0
        var failed = 0

        // adsb.lol is a public, free ADS-B source. Its global military list is a coverage-limited sample.
        try {
            val json = getJson("https://api.adsb.lol/v2/mil")
            val aircraft = json.optJSONArray("aircraft")
            val n = aircraft?.length() ?: 0
            if (n > 0) {
                val samples = (0 until minOf(n, 6)).mapNotNull { i ->
                    aircraft?.optJSONObject(i)?.let { a ->
                        val callsign = a.optString("flight", "unknown").trim()
                        val country = a.optString("r", "unknown registration")
                        "$callsign ($country)"
                    }
                }
                out += signal("ADS-B military aircraft snapshot: $n aircraft reported",
                    "Flight activity", "Global / receiver coverage", "adsb.lol public API",
                    "https://api.adsb.lol/docs", "Current snapshot count: $n. Sample identifiers: ${samples.joinToString(", ")}. Coverage is receiver-dependent; aircraft may be missing and a military registration alone does not imply unusual activity.",
                    3, 1, 2, 1, 2, false)
            }
            ok++
        } catch (e: Exception) { failed++; notes += "adsb.lol: ${e.message}" }

        // NWS public active alerts. Feed contains official alerts; cap records to avoid flooding.
        try {
            val json = getJson("https://api.weather.gov/alerts/active?limit=100",
                mapOf("User-Agent" to "WATCHTOWER-OSINT/5.0 (public data dashboard)"))
            val features = json.optJSONArray("features")
            var count = 0
            for (i in 0 until minOf(features?.length() ?: 0, 60)) {
                val feature = features?.optJSONObject(i) ?: continue
                val p = feature.optJSONObject("properties") ?: continue
                val event = p.optString("event", "NWS alert")
                val area = p.optString("areaDesc", "United States")
                val headline = p.optString("headline", event)
                val severity = p.optString("severity", "Unknown")
                val url = p.optString("@id", "https://api.weather.gov/alerts/active")
                out += signal("NWS $event: ${area.take(100)}", "Civil defence", area,
                    "National Weather Service", url, "$headline · Severity: $severity",
                    5, 1, if (severity == "Extreme" || severity == "Severe") 4 else 2,
                    if (severity == "Extreme" || severity == "Severe") 4 else 2, 3, true)
                count++
            }
            ok++
            notes += "NWS active alerts: $count"
        } catch (e: Exception) { failed++; notes += "NWS: ${e.message}" }

        // EIA latest hourly PJM regional data when the user has supplied a key.
        val eiaKey = SecureCredentialStore.get(context, "eia_key")
        if (eiaKey.isNotBlank()) {
            try {
                val url = "https://api.eia.gov/v2/electricity/rto/region-data/data/?api_key=${enc(eiaKey)}&frequency=hourly&data[0]=value&facets[respondent][]=PJM&sort[0][column]=period&sort[0][direction]=desc&length=1"
                val json = getJson(url)
                val rows = json.optJSONObject("response")?.optJSONArray("data")
                val row = rows?.optJSONObject(0)
                if (row != null) {
                    val value = row.optString("value", "not reported")
                    val period = row.optString("period", "unknown time")
                    out += signal("PJM electricity demand reading: $value MW",
                        "Energy infrastructure", "PJM Interconnection", "U.S. Energy Information Administration",
                        "https://www.eia.gov/opendata/", "Latest returned hourly regional value: $value MW for $period. A single reading is context only; anomaly detection requires a time-series baseline.",
                        5, 1, 2, 1, 3, true)
                }
                ok++
            } catch (e: Exception) { failed++; notes += "EIA: ${e.message}" }
        } else notes += "EIA skipped: add a free API key in Provider Access."

        // USAspending public API: query recent contract awards for Department of Defense.
        try {
            val payload = JSONObject()
                .put("filters", JSONObject()
                    .put("agencies", org.json.JSONArray().put(JSONObject().put("type", "awarding").put("tier", "toptier").put("name", "Department of Defense")))
                    .put("award_type_codes", org.json.JSONArray().put("A").put("B").put("C").put("D")))
                .put("fields", org.json.JSONArray().put("Award ID").put("Recipient Name").put("Award Amount").put("Start Date").put("Awarding Agency").put("Description"))
                .put("page", 1).put("limit", 10)
                .put("sort", "Start Date").put("order", "desc")
            val json = postJson("https://api.usaspending.gov/api/v2/search/spending_by_award/", payload)
            val rows = json.optJSONArray("results")
            var count = 0
            for (i in 0 until minOf(rows?.length() ?: 0, 10)) {
                val r = rows?.optJSONObject(i) ?: continue
                val desc = r.optString("Description", "Federal award")
                val recipient = r.optString("Recipient Name", "Recipient not listed")
                val amount = r.optString("Award Amount", "amount not listed")
                val awardId = r.optString("Award ID", "")
                out += signal("Federal award: ${desc.take(110)}",
                    "Government procurement", "United States", "USAspending.gov API",
                    "https://www.usaspending.gov/award/${awardId}", "Recipient: $recipient · Amount: $amount · Start: ${r.optString("Start Date")}. Award data is not necessarily evidence of unusual activity.",
                    5, 1, 2, 1, 2, true)
                count++
            }
            ok++
            notes += "USAspending recent DoD awards: $count"
        } catch (e: Exception) { failed++; notes += "USAspending: ${e.message}" }

        return Result(out, ok, failed, notes)
    }

    private fun signal(title: String, category: String, region: String, publisher: String,
                       url: String, summary: String, reliability: Int, corroboration: Int,
                       unusualness: Int, urgency: Int, impact: Int, official: Boolean) =
        Signal(UUID.nameUUIDFromBytes((publisher + title).toByteArray()).toString(), title,
            category, region, publisher, url, summary, System.currentTimeMillis(),
            reliability, corroboration, unusualness, urgency, impact, official)

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun getJson(address: String, headers: Map<String, String> = emptyMap()): JSONObject {
        val c = URL(address).openConnection() as HttpURLConnection
        c.requestMethod = "GET"; c.connectTimeout = 10000; c.readTimeout = 15000
        c.setRequestProperty("Accept", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        try {
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return JSONObject(body)
        } finally { c.disconnect() }
    }

    private fun postJson(address: String, payload: JSONObject): JSONObject {
        val c = URL(address).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 10000; c.readTimeout = 15000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Accept", "application/json")
        try {
            c.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return JSONObject(body)
        } finally { c.disconnect() }
    }
}
