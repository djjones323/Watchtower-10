package com.watchtower.osint

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class PizzaFreeSnapshot(
    val venuesFound: Int,
    val openNow: Int,
    val names: List<String>,
    val fetchedAt: Long,
    val note: String
)

object FreePizzaEngine {
    private const val PREF = "watchtower_free_pizza"
    private const val QUERY = """[out:json][timeout:20];(node["cuisine"~"pizza|italian"](around:3500,38.858,-77.052);way["cuisine"~"pizza|italian"](around:3500,38.858,-77.052);node["amenity"="restaurant"]["name"~"pizza",i](around:3500,38.858,-77.052);way["amenity"="restaurant"]["name"~"pizza",i](around:3500,38.858,-77.052););out center tags;"""

    fun fetch(context: Context): PizzaFreeSnapshot {
        val c = URL("https://overpass-api.de/api/interpreter").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 12000; c.readTimeout = 25000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        c.setRequestProperty("User-Agent", "WATCHTOWER-OSINT/6.1 (free public OSM POI lookup)")
        try {
            c.outputStream.use { it.write(("data=" + java.net.URLEncoder.encode(QUERY, "UTF-8")).toByteArray()) }
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("OpenStreetMap Overpass HTTP $code")
            val elements = JSONObject(body).optJSONArray("elements") ?: JSONArray()
            val names = linkedSetOf<String>()
            var open = 0
            for (i in 0 until elements.length()) {
                val tags = elements.optJSONObject(i)?.optJSONObject("tags") ?: continue
                val name = tags.optString("name", "").trim()
                if (name.isBlank()) continue
                names += name
                val hours = tags.optString("opening_hours", "")
                if (hours.isNotBlank() && hours.lowercase().contains("24/7")) open++
            }
            val snap = PizzaFreeSnapshot(names.size, open, names.toList().take(40),
                System.currentTimeMillis(),
                "OpenStreetMap venue directory only. Open-now status is not reliably encoded; only explicitly tagged 24/7 venues are counted. This is NOT foot traffic.")
            context.getSharedPreferences(PREF, 0).edit()
                .putString("snapshot", JSONObject().put("count", snap.venuesFound).put("open", snap.openNow)
                    .put("names", JSONArray(snap.names)).put("time", snap.fetchedAt).put("note", snap.note).toString()).apply()
            return snap
        } finally { c.disconnect() }
    }

    fun load(context: Context): PizzaFreeSnapshot? = try {
        val o = JSONObject(context.getSharedPreferences(PREF, 0).getString("snapshot", null) ?: return null)
        val a = o.optJSONArray("names") ?: JSONArray()
        PizzaFreeSnapshot(o.optInt("count"), o.optInt("open"),
            (0 until a.length()).map { a.optString(it) }, o.optLong("time"), o.optString("note"))
    } catch (_: Exception) { null }

    fun saveManualObservation(context: Context, score: Int, note: String) {
        val prefs = context.getSharedPreferences(PREF, 0)
        val a = try { JSONArray(prefs.getString("observations", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        a.put(JSONObject().put("score", score.coerceIn(1,10)).put("note", note)
            .put("time", System.currentTimeMillis()).put("source", "Manual Google Maps Popular Times observation"))
        val trimmed = JSONArray()
        for (i in (a.length()-100).coerceAtLeast(0) until a.length()) trimmed.put(a.getJSONObject(i))
        prefs.edit().putString("observations", trimmed.toString()).apply()
    }

    fun latestManualObservation(context: Context): JSONObject? = try {
        val a = JSONArray(context.getSharedPreferences(PREF, 0).getString("observations", "[]") ?: "[]")
        if (a.length() == 0) null else a.getJSONObject(a.length()-1)
    } catch (_: Exception) { null }
}
