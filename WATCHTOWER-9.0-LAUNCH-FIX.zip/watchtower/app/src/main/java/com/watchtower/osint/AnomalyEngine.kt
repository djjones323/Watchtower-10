package com.watchtower.osint

import kotlin.math.min

data class Hotspot(val region:String,val latitude:Float,val longitude:Float,val score:Int,val signalCount:Int,val categories:List<String>,val publishers:Int,val explanation:String)
object AnomalyEngine {
 private val geo=mapOf("United States" to (39f to -98f),"Washington, DC" to (38.9f to -77f),"Europe" to (50f to 12f),"United Kingdom" to (54f to -2f),"France" to (46f to 2f),"Germany" to (51f to 10f),"Ukraine" to (49f to 32f),"Russia" to (60f to 90f),"Middle East" to (29f to 43f),"Israel" to (31f to 35f),"Iran" to (32f to 53f),"China" to (35f to 103f),"Taiwan" to (23.5f to 121f),"Japan" to (36f to 138f),"India" to (21f to 78f),"International" to (12f to 0f))
 fun analyze(signals:List<Signal>):List<Hotspot>{
  val cutoff=System.currentTimeMillis()-72L*60*60*1000
  return signals.filter{it.date>=cutoff}.groupBy{normalize(it.region)}.map{(region,items)->
   val cats=items.map{it.category}.distinct(); val pubs=items.map{it.publisher}.distinct().size; val official=items.count{it.official}; val high=items.count{it.score()>=7}
   val volume=min(10,items.size*2); val diversity=min(10,cats.size*2); val corroboration=min(10,pubs*2)
   val score=(volume*.25+diversity*.25+corroboration*.20+(official*10/items.size)*.15+(high*10/items.size)*.15).toInt().coerceIn(1,10)
   val point=geo[region]?:when{region.contains("Europe",true)->geo.getValue("Europe");region.contains("Asia",true)->(30f to 105f);region.contains("Africa",true)->(2f to 20f);else->geo.getValue("International")}
   Hotspot(region,point.first,point.second,score,items.size,cats,pubs,"${items.size} records across ${cats.size} categories from $pubs distinct publishers in the last 72 hours; $official records are from feeds classified as official.")
  }.filter{it.signalCount>=2}.sortedByDescending{it.score}
 }
 private fun normalize(raw:String):String { val s=raw.trim(); return when {s.isBlank()->"International";s.contains("Washington",true)||s.contains("Pentagon",true)->"Washington, DC";s.contains("United States",true)||s.equals("US",true)||s.equals("USA",true)->"United States";else->geo.keys.firstOrNull{s.contains(it,true)}?:s} }
}
