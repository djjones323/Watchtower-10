package com.watchtower.osint

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class GlobeView(context:Context,private var hotspots:List<Hotspot>,private val onSelect:(Hotspot)->Unit):View(context){
 private val fill=Paint(3).apply{color=Color.rgb(10,27,42)};private val grid=Paint(3).apply{color=Color.argb(65,120,190,210);style=Paint.Style.STROKE;strokeWidth=1.3f};private val rim=Paint(3).apply{color=Color.rgb(74,157,190);style=Paint.Style.STROKE;strokeWidth=3f};private val dot=Paint(3);private var cx=0f;private var cy=0f;private var r=0f;private var selected:Hotspot?=null
 fun update(items:List<Hotspot>){hotspots=items;invalidate()}
 override fun onDraw(c:Canvas){super.onDraw(c);cx=width/2f;cy=height/2f;r=min(width*.43f,height*.43f);c.drawCircle(cx,cy,r,fill);val path=Path().apply{addCircle(cx,cy,r,Path.Direction.CW)};val save=c.save();c.clipPath(path)
  for(i in -3..3){val y=cy+i*r/4f;val half=sqrt(max(0f,r*r-(y-cy)*(y-cy)));c.drawOval(RectF(cx-half,y-r*.13f,cx+half,y+r*.13f),grid)}
  for(i in -2..2){val x=cx+i*r/3f;val half=sqrt(max(0f,r*r-(x-cx)*(x-cx)));c.drawOval(RectF(x-r*.17f,cy-half,x+r*.17f,cy+half),grid)}
  val land=Paint(3).apply{color=Color.rgb(28,65,69)};c.drawOval(RectF(cx-r*.72f,cy-r*.45f,cx-r*.25f,cy+r*.18f),land);c.drawOval(RectF(cx-r*.18f,cy-r*.52f,cx+r*.42f,cy-r*.12f),land);c.drawOval(RectF(cx-r*.1f,cy-r*.03f,cx+r*.2f,cy+r*.65f),land);c.drawOval(RectF(cx+r*.36f,cy-r*.42f,cx+r*.78f,cy+r*.18f),land)
  hotspots.forEach{h->val q=point(h);val color=if(h.score>=8)Color.rgb(255,105,91) else if(h.score>=5)Color.rgb(255,190,80) else Color.rgb(91,210,172);dot.color=Color.argb(55,Color.red(color),Color.green(color),Color.blue(color));c.drawCircle(q.first,q.second,10f+h.score*1.8f,dot);dot.color=color;c.drawCircle(q.first,q.second,4f+h.score,dot);if(selected==h)c.drawCircle(q.first,q.second,13f+h.score,rim)}
  c.restoreToCount(save);c.drawCircle(cx,cy,r,rim)
 }
 private fun point(h:Hotspot)=Pair(cx+h.longitude/180f*r*.88f,cy-h.latitude/90f*r*.82f)
 override fun onTouchEvent(e:MotionEvent):Boolean{if(e.action==MotionEvent.ACTION_UP){val hit=hotspots.map{Triple(it,point(it),18f+it.score)}.map{Triple(it.first,hypot(e.x-it.second.first,e.y-it.second.second),it.third)}.filter{it.second<it.third}.minByOrNull{it.second};if(hit!=null){selected=hit.first;invalidate();onSelect(hit.first);performClick()}};return true}
 override fun performClick():Boolean{super.performClick();return true}
}
