package com.watchtower.osint

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

class MapHomeActivity : Activity() {
    private var web: WebView? = null
    private val bg = Color.rgb(3, 8, 15)
    private val blue = Color.rgb(0, 210, 255)
    private val amber = Color.rgb(255, 173, 75)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        val frame = FrameLayout(this).apply { setBackgroundColor(bg) }
        val map = WebView(this).apply {
            setBackgroundColor(bg)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
        }
        web = map
        frame.addView(map, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(14, 36, 14, 8)
            setBackgroundColor(Color.argb(185, 3, 12, 23))
        }
        val brand = TextView(this).apply {
            text = "WATCHTOWER\\nGLOBAL ANOMALY FIELD"
            setTextColor(Color.WHITE); textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            letterSpacing = .08f
        }
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(smallButton("LAYERS") { showLayers() })
        top.addView(smallButton("INTEL") { startActivity(Intent(this, MainActivity::class.java)) })
        frame.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(10, 7, 10, 12)
            setBackgroundColor(Color.argb(205, 3, 12, 23))
        }
        bottom.addView(smallButton("↻ REFRESH") { refreshMap() }, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(smallButton("PROVIDERS") {
            startActivity(Intent(this, ProviderAccessActivity::class.java))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(smallButton("RESET VIEW") { web?.evaluateJavascript("map.setView([22,8],2);", null) },
            LinearLayout.LayoutParams(0, -2, 1f))
        frame.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(frame)
        renderMap()
    }

    private fun smallButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 10f; setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(20, 65, 88))
        setPadding(8, 3, 8, 3)
        setOnClickListener { action() }
    }

    private fun showLayers() {
        val categories = Categories.all
        val labels = categories.map { "•  $it" }.toTypedArray()
        android.app.AlertDialog.Builder(this).setTitle("MAP DATA LAYERS")
            .setItems(labels) { _, which ->
                web?.evaluateJavascript("toggleCategory(${JSONObject.quote(categories[which])});", null)
            }.setNegativeButton("Close", null).show()
    }

    private fun refreshMap() {
        Thread {
            try {
                val rss = FeedEngine.fetchAll()
                val apis = PublicApiEngine.fetch(this)
                val merged = (SignalStore.load(this) + rss.signals + apis.signals)
                    .distinctBy { it.id }.sortedByDescending { it.date }.take(600)
                SignalStore.save(this, merged)
                runOnUiThread { renderMap() }
            } catch (_: Exception) {
                runOnUiThread { renderMap() }
            }
        }.start()
    }

    private fun renderMap() {
        val signals = SignalStore.load(this)
        val hotspots = AnomalyEngine.analyze(signals)
        val data = JSONArray()
        hotspots.forEach { h ->
            data.put(JSONObject().put("region", h.region).put("lat", h.latitude)
                .put("lon", h.longitude).put("score", h.score).put("count", h.signalCount)
                .put("categories", h.categories.joinToString(" · "))
                .put("publishers", h.publishers).put("explanation", h.explanation))
        }
        val html = """
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
*{box-sizing:border-box}html,body,#map{height:100%;width:100%;margin:0;background:#03080f;font-family:Arial,sans-serif;overflow:hidden}
.leaflet-tile-pane{filter:invert(1) hue-rotate(180deg) brightness(.72) contrast(1.12)}
.leaflet-control-attribution{background:rgba(2,8,16,.7)!important;color:#8297aa!important;font-size:8px!important}
.leaflet-control-attribution a{color:#7ddcff!important}
.hud{position:absolute;z-index:700;background:rgba(4,13,26,.9);border:1px solid rgba(0,211,255,.45);color:#e8f7ff}
.metrics{left:12px;top:102px;padding:9px 11px;font-size:10px;line-height:1.7;max-width:170px}
.metrics b{color:#00d9ff;letter-spacing:1px}
.legend{right:12px;top:102px;padding:8px;font-size:9px;line-height:1.8}
.dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:5px}
.detail{left:12px;right:12px;bottom:70px;padding:10px 12px;font-size:10px;line-height:1.4;max-height:23%;overflow:auto}
.detail strong{color:#00d9ff;letter-spacing:1px}
.leaflet-popup-content-wrapper,.leaflet-popup-tip{background:#081727;color:#e8f7ff;border:1px solid #087b9c}
.leaflet-popup-content{font-size:11px;line-height:1.45}
</style></head><body>
<div id="map"></div>
<div class="hud metrics"><b>GLOBAL ANOMALY FIELD</b><br>RECORDS: ${signals.size}<br>HOTSPOTS: ${hotspots.size}<br>HIGH INTEREST: ${hotspots.count { it.score >= 8 }}<br>WINDOW: 72 HOURS</div>
<div class="hud legend"><span class="dot" style="background:#ff3d55"></span>HIGH<br><span class="dot" style="background:#ff9b39"></span>ELEVATED<br><span class="dot" style="background:#a65cff"></span>WATCH</div>
<div class="hud detail"><strong id="sel">SELECT A HOTSPOT</strong><div id="desc">Tap a heat zone to inspect its evidence. Heat represents clustered public records, not threat probability.</div></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const items=__DATA__;
const map=L.map('map',{worldCopyJump:true,zoomControl:true,minZoom:2,maxZoom:9}).setView([22,8],2);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);
let layers=[];
function col(v){return v>=8?'#ff3d55':v>=5?'#ff9b39':'#a65cff'}
function toggleCategory(cat){layers.forEach(x=>{if(x.cat===cat)x.layer.setStyle({opacity:x.layer.options.opacity===0?0.8:0})})}
function select(h){document.getElementById('sel').textContent=h.region.toUpperCase()+' · INDEX '+h.score+'/10';document.getElementById('desc').textContent=h.count+' records · '+h.categories+' · '+h.publishers+' publishers. '+h.explanation+' Activity indicator only; not a threat assessment.'}
items.forEach(h=>{
 const c=col(h.score);
 const halo=L.circle([h.lat,h.lon],{radius:240000+h.score*95000,color:c,weight:1,opacity:.6,fillColor:c,fillOpacity:.19}).addTo(map);
 const pin=L.circleMarker([h.lat,h.lon],{radius:5+h.score,color:'#fff',weight:1,fillColor:c,fillOpacity:1}).addTo(map);
 pin.bindPopup('<b>'+h.region+'</b><br>Index '+h.score+'/10<br>'+h.count+' records');
 pin.on('click',()=>select(h));
 layers.push({cat:h.categories,layer:halo});
});
if(items.length)select(items[0]);
</script></body></html>
        """.trimIndent().replace("__DATA__", data.toString())
        web?.loadDataWithBaseURL("https://unpkg.com/", html, "text/html", "UTF-8", null)
    }
}
