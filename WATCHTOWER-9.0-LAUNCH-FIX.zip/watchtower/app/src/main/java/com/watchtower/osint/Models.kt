package com.watchtower.osint

import org.json.JSONArray
import org.json.JSONObject

object Categories {
    val all = listOf(
        "Restaurant activity", "Embassy activity", "Flight activity", "Maritime activity",
        "Energy infrastructure", "Communications", "Government procurement",
        "Civil defence", "Financial signals"
    )
}

data class Signal(
    val id: String,
    val title: String,
    val category: String,
    val region: String,
    val publisher: String,
    val url: String,
    val summary: String,
    val date: Long,
    val sourceReliability: Int,
    val corroboration: Int,
    val unusualness: Int,
    val urgency: Int,
    val impact: Int,
    val official: Boolean,
    val timing: String = "Not stated",
    val manual: Boolean = false
) {
    fun imminenceScore(): Int = when(timing) {
        "Immediate official warning" -> 10
        "Expected within 7 days" -> 8
        "Expected within 30 days" -> 6
        "Ongoing" -> 4
        "Historical" -> 1
        else -> 1
    }
    fun score(): Int {
        val raw = sourceReliability.coerceIn(1,5) * .30 +
            corroboration.coerceIn(1,5) * .25 + unusualness.coerceIn(1,5) * .20 +
            urgency.coerceIn(1,5) * .15 + impact.coerceIn(1,5) * .10
        return (raw * 2).toInt().coerceIn(1,10)
    }
    fun toJson() = JSONObject().apply {
        put("id",id); put("title",title); put("category",category); put("region",region)
        put("publisher",publisher); put("url",url); put("summary",summary); put("date",date)
        put("sourceReliability",sourceReliability); put("corroboration",corroboration)
        put("unusualness",unusualness); put("urgency",urgency); put("impact",impact)
        put("official",official); put("timing",timing); put("manual",manual)
    }
    companion object {
        fun fromJson(o: JSONObject) = Signal(
            o.optString("id"), o.optString("title"), o.optString("category"),
            o.optString("region"), o.optString("publisher"), o.optString("url"),
            o.optString("summary"), o.optLong("date"), o.optInt("sourceReliability",2),
            o.optInt("corroboration",1), o.optInt("unusualness",2),
            o.optInt("urgency",1), o.optInt("impact",2), o.optBoolean("official"),
            o.optString("timing","Not stated"), o.optBoolean("manual")
        )
    }
}

object SignalStore {
    private const val PREF = "watchtower_store"
    private const val KEY = "signals"
    private const val HISTORY_KEY = "refresh_history"
    fun load(context: android.content.Context): MutableList<Signal> {
        val raw = context.getSharedPreferences(PREF,0).getString(KEY,"[]") ?: "[]"
        return try {
            val a = JSONArray(raw); MutableList(a.length()) { Signal.fromJson(a.getJSONObject(it)) }
        } catch (_: Exception) { mutableListOf() }
    }
    fun save(context: android.content.Context, items: List<Signal>) {
        val a = JSONArray(); items.forEach { a.put(it.toJson()) }
        context.getSharedPreferences(PREF,0).edit().putString(KEY,a.toString()).apply()
    }
    fun saveRefreshSnapshot(context: android.content.Context, itemCount: Int, newCount: Int, failedFeeds: Int) {
        val prefs = context.getSharedPreferences(PREF, 0)
        val history = try { JSONArray(prefs.getString(HISTORY_KEY, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        history.put(JSONObject().put("time", System.currentTimeMillis()).put("items", itemCount)
            .put("new", newCount).put("failed", failedFeeds))
        val trimmed = JSONArray()
        val start = (history.length() - 24).coerceAtLeast(0)
        for (i in start until history.length()) trimmed.put(history.getJSONObject(i))
        prefs.edit().putString(HISTORY_KEY, trimmed.toString()).apply()
    }
    fun loadRefreshHistory(context: android.content.Context): JSONArray {
        return try { JSONArray(context.getSharedPreferences(PREF, 0).getString(HISTORY_KEY, "[]") ?: "[]") }
        catch (_: Exception) { JSONArray() }
    }
    fun loadWatchlist(context: android.content.Context): List<String> {
        val raw = context.getSharedPreferences(PREF, 0).getString("watchlist", null)
        return raw?.split("\n")?.map { it.trim() }?.filter { it.isNotBlank() }
            ?: listOf("evacuation", "shelter in place", "airspace closure", "undersea cable",
                "GPS jamming", "power grid outage", "emergency declaration", "embassy departure")
    }
    fun saveWatchlist(context: android.content.Context, words: List<String>) {
        context.getSharedPreferences(PREF, 0).edit()
            .putString("watchlist", words.map { it.trim() }.filter { it.isNotBlank() }.distinct().joinToString("\n")).apply()
    }
}
